package com.rrmotor.sms;
import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
public class MainActivity extends Activity {
    EditText nama,hp,motor,nopol,km; TextView status;
    public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(24,24,24,24);
        TextView t=new TextView(this); t.setText("RR MOTOR\nPengingat Ganti Oli"); t.setTextSize(24); l.addView(t);
        nama=e("Nama pelanggan (opsional)"); hp=e("No. HP *"); motor=e("Jenis motor (opsional)"); nopol=e("No. polisi (opsional)"); km=e("KM (opsional)");
        l.addView(nama);l.addView(hp);l.addView(motor);l.addView(nopol);l.addView(km);
        Button s=new Button(this); s.setText("Kirim SMS"); l.addView(s); status=new TextView(this); l.addView(status); setContentView(l);
        if(checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.SEND_SMS},10);
        s.setOnClickListener(v->send());
    }
    EditText e(String h){EditText x=new EditText(this);x.setHint(h);x.setSingleLine();return x;}
    void send(){
        if(hp.getText().toString().trim().isEmpty()){status.setText("No. HP wajib diisi.");return;}
        String d=new SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(new Date());
        String msg="Yth. Bapak/Ibu "+nama.getText()+",\n\nRR MOTOR mengingatkan bahwa "+motor.getText()+" No. Pol "+nopol.getText()+" sudah mendekati jadwal penggantian oli.\n\nTerakhir ganti oli: "+d+"\nKM: "+km.getText()+"\n\nPenggantian oli setiap 1500 KM penting untuk menjaga performa dan usia mesin.\n\nKami tunggu kedatangan Bapak/Ibu di RR MOTOR.\n\nTim RR MOTOR";
        try{SmsManager.getDefault().sendTextMessage(hp.getText().toString(),null,msg,null,null);status.setText("SMS sudah diperintahkan untuk dikirim.");}
        catch(Exception e){status.setText("Gagal: "+e.getMessage());}
    }
}
