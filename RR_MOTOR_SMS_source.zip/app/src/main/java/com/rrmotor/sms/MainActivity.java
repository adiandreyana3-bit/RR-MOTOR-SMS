package com.rrmotor.sms;

import android.Manifest;
import android.app.*;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.*;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    EditText nama, hp, motor, nopol, km;
    TextView status;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(24,24,24,24);
        TextView title=new TextView(this); title.setText("RR MOTOR\nPengingat Ganti Oli"); title.setTextSize(24); l.addView(title);
        nama=e("Nama *"); hp=e("No. HP *"); motor=e("Jenis Motor *"); nopol=e("No. Polisi (opsional)"); km=e("KM (opsional)");
        l.addView(nama);l.addView(hp);l.addView(motor);l.addView(nopol);l.addView(km);
        Button send=new Button(this); send.setText("Kirim SMS Pengingat"); l.addView(send);
        status=new TextView(this); l.addView(status);
        setContentView(l);
        if(checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.SEND_SMS},10);
        send.setOnClickListener(v->sendSms());
    }
    EditText e(String hint){ EditText x=new EditText(this); x.setHint(hint); x.setSingleLine(); return x; }
    void sendSms(){
        if(nama.getText().length()==0||hp.getText().length()==0||motor.getText().length()==0){status.setText("Lengkapi Nama, No. HP, dan Jenis Motor.");return;}
        String date=new SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(new Date());
        String msg="Yth. Bapak/Ibu "+nama.getText()+",\n\nDengan hormat, kami dari RR MOTOR mengingatkan bahwa "+motor.getText()+" No. Pol "+nopol.getText()+" sudah mendekati jadwal penggantian oli.\n\nTerakhir ganti oli: "+date+"\nKM: "+km.getText()+"\n\nPenggantian oli setiap 1500 KM sangat penting untuk menjaga performa dan usia mesin kendaraan.\n\nKami tunggu kedatangan Bapak/Ibu di RR MOTOR.\nTerima kasih atas kepercayaannya.\n\nTim RR MOTOR";
        try { SmsManager.getDefault().sendTextMessage(hp.getText().toString(),null,msg,null,null); status.setText("SMS sudah diperintahkan untuk dikirim."); }
        catch(Exception ex){ status.setText("Gagal mengirim SMS: "+ex.getMessage()); }
    }
}
